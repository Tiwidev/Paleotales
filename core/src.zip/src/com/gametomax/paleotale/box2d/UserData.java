package com.gametomax.paleotale.box2d;

import com.gametomax.paleotale.enums.UserDataType;

public abstract class UserData {


    protected UserDataType userDataType;
    protected float height;
    protected float width;
    private boolean next;


    public UserData(float width, float height) {
        this.width = width;
        this.height = height;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public UserDataType getUserDataType() {
        return userDataType;
    }

    public boolean hasNext() {
        return next;
    }

    public void setNext(boolean next) {
        this.next = next;
    }

}