package com.gametomax.paleotale.actors;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.gametomax.paleotale.utils.Constants;

import static com.gametomax.paleotale.utils.Constants.getGroundSpeed;

public class Background extends Actor {

    public final TextureRegion textureRegion;
    public Rectangle textureRegionBounds1;
    public Rectangle textureRegionBounds2;

    public Background() {
        textureRegion = new TextureRegion(new Texture(Gdx.files.internal(Constants.BACKGROUND_IMAGE_PATH)));
        textureRegionBounds1 = new Rectangle(0 - Constants.APP_WIDTH*2, 0, Constants.APP_WIDTH*3, Constants.APP_HEIGHT);
        textureRegionBounds2 = new Rectangle(Constants.APP_WIDTH, 0, Constants.APP_WIDTH*3, Constants.APP_HEIGHT);
    }

    @Override
    public void act(float delta) {
        if (leftBoundsReached()) {
            resetBounds();
        } else {
            updateXBounds();
        }
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        super.draw(batch, parentAlpha);
    }

    private boolean leftBoundsReached() {
        return (textureRegionBounds2.x - Constants.GROUND_VELOCITY) <= -Constants.APP_WIDTH*2;
    }

    private void updateXBounds() {
        textureRegionBounds1.x -= Constants.GROUND_VELOCITY;
        textureRegionBounds2.x -= Constants.GROUND_VELOCITY;
    }

    private void resetBounds() {
        textureRegionBounds1 = textureRegionBounds2;
        textureRegionBounds2 = new Rectangle(Constants.APP_WIDTH, 0, Constants.APP_WIDTH*3, Constants.APP_HEIGHT);
    }

}