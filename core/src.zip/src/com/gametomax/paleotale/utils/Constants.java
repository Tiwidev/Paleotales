package com.gametomax.paleotale.utils;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.math.Vector2;

import static java.lang.Float.max;

public class Constants {

    public static final int APP_WIDTH = 20;
    public static final int APP_HEIGHT = 11;
    public static final float GRAVITY_INTENSITY = 10f;
    public static final Vector2 WORLD_GRAVITY = new Vector2(0, -GRAVITY_INTENSITY);
    public static float TO_PIXEL_RATIO = 0.0095f;

    public static final float GROUND_Y = 0;
    public static final float GROUND_WIDTH = 2f;
    public static final float GROUND_HEIGHT = 1f;
    public static final float GROUND_DENSITY = 0.0f;
    public static final float GROUND_VELOCITY = 0.1f;
    public static final float GROUND_TO_RUNNER = 0.2f;

    public static final int MAX_PLATFORM_LENGTH = 8;
    public static final int MIN_PLATFORM_LENGTH = 4;

    public static final float RUNNER_WIDTH = 0.4f;
    public static final float RUNNER_HEIGHT = 0.5f;
    public static final float RUNNER_X = 6;
    public static final float RUNNER_Y = GROUND_HEIGHT + RUNNER_HEIGHT;
    public static final float RUNNER_GRAVITY_SCALE = 2f;
    public static float RUNNER_DENSITY = 1.5f;
    public static final float RUNNER_DODGE_X = RUNNER_X;
    public static final float RUNNER_DODGE_Y = GROUND_HEIGHT - RUNNER_WIDTH + RUNNER_HEIGHT;
    public static final Vector2 RUNNER_JUMPING_LINEAR_IMPULSE = new Vector2(0, GRAVITY_INTENSITY + 1);
    public static final float RUNNER_FRAME_DURATION = 0.08f;
    public static final float MAX_SPEED = 2.0f;

    public static final String BACKGROUND_IMAGE_PATH = "fond.png";
    public static final String GROUND_IMAGE_PATH = "ground.png";
    public static final String HOLE_IMAGE_PATH = "hole.png";
    public static final String VIGNETTE_IMAGE_PATH = "vignette.png";
    public static final String[] RUNNER_RUNNING_REGION_NAMES = getIncrementalString("Perso Rigg_000",15,2);

    public static final String FONT_NAME = "font.fnt";
    public static final float FONT_SCALE = 2f;
    public static final float FONT_SIZE = FONT_SCALE*32f;


    public static String[] getIncrementalString(String init,int number,int padding) {
        String[] result = new String[number];
        for (int i=0; i<number;i++) {
            result[i] = init + String.format("%0" + Integer.toString(padding) +"d" , i) + ".png";
        }
        return result;
    }

    public static float getGroundSpeed(double time) {
        double elapsed = System.currentTimeMillis() - time;
        float multiplier = (float)Math.log(1.0 + elapsed/10000.0);
        if (multiplier > MAX_SPEED){
            multiplier =  MAX_SPEED;
        }
        return  1.0f;
    }

}
