package com.gametomax.paleotale.stages;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.Manifold;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.utils.Array;
import com.gametomax.paleotale.actors.Background;
import com.gametomax.paleotale.actors.Score;
import com.gametomax.paleotale.utils.Constants;
import com.gametomax.paleotale.utils.WorldUtils;
import com.gametomax.paleotale.actors.Runner;
import com.gametomax.paleotale.actors.Ground;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;

import java.util.Random;

import static com.gametomax.paleotale.utils.BodyUtils.bodyGroundHasNext;
import static com.gametomax.paleotale.utils.BodyUtils.bodyIsGround;
import static com.gametomax.paleotale.utils.BodyUtils.bodyIsRunner;
import static com.gametomax.paleotale.utils.Constants.getGroundSpeed;
import static com.gametomax.paleotale.utils.WorldUtils.createGround;

public class GameStage extends Stage implements ContactListener {

    private World world;
    private Runner runner;
    private Ground ground;
    private Background bg;
    private Texture ground_texture;
    private Texture hole_texture;
    private Texture vignette_texture;
    private final float TIME_STEP = 1 / 300f;
    private float accumulator = 0f;
    public SpriteBatch batch;
    public SpriteBatch batch_ui;
    private Score score;
    double startTime;

    public OrthographicCamera camera;
    public OrthographicCamera camera_ui;
    private Box2DDebugRenderer renderer;

    private Rectangle screenLeftSide;
    private Rectangle screenRightSide;

    private Vector3 touchPoint;

    public GameStage() {
        setUpWorld();
        setupCamera();
        setupTouchControlAreas();
        renderer = new Box2DDebugRenderer();
        ground_texture = new Texture(Gdx.files.internal(Constants.GROUND_IMAGE_PATH));
        hole_texture = new Texture(Gdx.files.internal(Constants.HOLE_IMAGE_PATH));
        vignette_texture = new Texture(Gdx.files.internal(Constants.VIGNETTE_IMAGE_PATH));
    }

    private void setUpWorld() {
        world = WorldUtils.createWorld();
        // Let the world now you are handling contacts
        world.setContactListener(this);
        setUpBackground();

        generatePlatform(0, 5);
        generatePlatform(12*Constants.GROUND_WIDTH,5);
        setUpRunner();
        setUpScore();
        startTime = System.currentTimeMillis();
    }

    private void setUpBackground() {
        bg = new Background();
        addActor(bg);
    }

    private void setUpRunner() {
        runner = new Runner(WorldUtils.createRunner(world));
        addActor(runner);
    }

    private void setupCamera() {
        camera = new OrthographicCamera(Constants.APP_WIDTH, Constants.APP_HEIGHT);
        camera.position.set(camera.viewportWidth / 2, camera.viewportHeight / 2, 0f);
        camera.update();
        batch = new SpriteBatch();
        batch.setProjectionMatrix(camera.combined);
        camera_ui = new OrthographicCamera(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        camera_ui.position.set(camera_ui.viewportWidth / 2, camera_ui.viewportHeight / 2, 0f);
        camera_ui.update();
        batch_ui = new SpriteBatch();
        batch_ui.setProjectionMatrix(camera_ui.combined);
    }

    private void setupTouchControlAreas() {
        touchPoint = new Vector3();
        screenLeftSide = new Rectangle(0, 0, getCamera().viewportWidth / 2, getCamera().viewportHeight);
        screenRightSide = new Rectangle(getCamera().viewportWidth / 2, 0, getCamera().viewportWidth / 2,
                getCamera().viewportHeight);
        Gdx.input.setInputProcessor(this);
    }

    private void setUpScore() {
        Rectangle scoreBounds = new Rectangle(Constants.APP_WIDTH* Constants.TO_PIXEL_RATIO * 47 / 64,
                Constants.APP_HEIGHT* Constants.TO_PIXEL_RATIO * 57 / 64, Constants.APP_WIDTH* Constants.TO_PIXEL_RATIO / 4,
                Constants.APP_HEIGHT* Constants.TO_PIXEL_RATIO / 8);
        score = new Score(scoreBounds);
        addActor(score);
    }

    @Override
    public void act(float delta) {
        super.act(delta);
        Array<Body> bodies = new Array<Body>(world.getBodyCount());
        world.getBodies(bodies);
        batch.begin();
        //TODO
        batch.draw(bg.textureRegion, bg.textureRegionBounds1.x, bg.textureRegionBounds1.y, Constants.APP_WIDTH*3,
                Constants.APP_HEIGHT);
        batch.draw(bg.textureRegion, bg.textureRegionBounds2.x, bg.textureRegionBounds2.y, Constants.APP_WIDTH*3,
                Constants.APP_HEIGHT);
        float furthest_ground = 0f;
        for (Body body : bodies) {
            if (bodyIsGround(body)) {
                if (body.getPosition().x > furthest_ground) {
                    furthest_ground = body.getPosition().x;
                }
                updateGround(body);
            } else if (bodyIsRunner(body)) {
                if (body.getPosition().y < -2*Constants.RUNNER_HEIGHT) {
                    restart();
                }
                body.applyForceToCenter(Constants.WORLD_GRAVITY, true);
                // Running
                runner.stateTime += Gdx.graphics.getDeltaTime();
                batch.draw((TextureRegion) runner.runningAnimation.getKeyFrame(runner.stateTime, true), body.getPosition().x - Constants.RUNNER_WIDTH*2,body.getPosition().y - Constants.RUNNER_HEIGHT - Constants.GROUND_TO_RUNNER,Constants.RUNNER_WIDTH*4,Constants.RUNNER_HEIGHT*2);
            }
        }
        batch.draw(vignette_texture,0,0,Constants.APP_WIDTH,Constants.APP_HEIGHT);
        int length = ("" + score.getScore()).length();
        batch.end();
        batch_ui.begin();
        score.getFont().draw(batch_ui, "" + score.getScore(),
                Gdx.graphics.getWidth() - length*Constants.FONT_SIZE, Gdx.graphics.getHeight() - Constants.FONT_SIZE);
        batch_ui.end();
        runner.runningAnimation.setFrameDuration(Constants.RUNNER_FRAME_DURATION/getGroundSpeed(startTime));

        //uncomment to see debug bodies
        //

        if (furthest_ground < Constants.APP_WIDTH) {
            generatePlatform(furthest_ground + 4*Constants.GROUND_WIDTH,0);
        }

        // Fixed timestep
        accumulator += delta;

        while (accumulator >= delta) {
            world.step(TIME_STEP, 6, 2);
            accumulator -= TIME_STEP;
        }

    }

    private void generatePlatform(float x, int length) {
        if (length == 0) {
            Random random = new Random();
            length = random.nextInt((Constants.MAX_PLATFORM_LENGTH - Constants.MIN_PLATFORM_LENGTH) + 1) + Constants.MIN_PLATFORM_LENGTH;
        }
        for (float i = 0; i < length; i++) {
            ground = new Ground(createGround(world, x + i*Constants.GROUND_WIDTH*2,Constants.GROUND_WIDTH));
            addActor(ground);
        }
        ground.setNext(true);
    }

    private void updateGround(Body body) {
        body.setTransform(body.getPosition().x - getGroundSpeed(startTime)*Constants.GROUND_VELOCITY, body.getPosition().y,0);
        batch.draw(ground_texture, body.getPosition().x-Constants.GROUND_WIDTH, body.getPosition().y-Constants.GROUND_HEIGHT, Constants.GROUND_WIDTH*2,
                Constants.GROUND_HEIGHT*2);
        if (bodyGroundHasNext(body)) {
            batch.draw(hole_texture, body.getPosition().x+Constants.GROUND_WIDTH, body.getPosition().y-Constants.GROUND_HEIGHT, Constants.GROUND_WIDTH*2,
                    Constants.GROUND_HEIGHT*2);
        }
        if (body.getPosition().x < -4*Constants.GROUND_WIDTH) {
            world.destroyBody(body);
        }
    }

    @Override
    public void draw() {
        super.draw();
    }

    public void restart() {
        Array<Body> bodies = new Array<Body>(world.getBodyCount());
        world.getBodies(bodies);
        for(Body body : bodies) {
            world.destroyBody(body);
        }
        for(Actor actor : this.getActors()) {
            actor.remove();
        }
        setUpWorld();
    }

    @Override
    public boolean touchDown(int x, int y, int pointer, int button) {

        // Need to get the actual coordinates
        translateScreenToWorldCoordinates(x, y);
        //TODO: if player in touch with the ground
        Array<Body> bodies = new Array<Body>(world.getBodyCount());
        world.getBodies(bodies);
        boolean can_jump = false;
        for (Body body : bodies) {
            if (bodyIsGround(body) && body.getPosition().x - Constants.GROUND_WIDTH <= Constants.RUNNER_X && body.getPosition().x + Constants.GROUND_WIDTH >=  Constants.RUNNER_X) {
                can_jump = true;
            }
        }

        if (can_jump) {
            if (rightSideTouched(touchPoint.x, touchPoint.y)) {
                runner.jump();
            } else if (leftSideTouched(touchPoint.x, touchPoint.y)) {
                //TODO implement dodge
                //runner.dodge();
                runner.jump();
            }
        }

        return super.touchDown(x, y, pointer, button);
    }

    @Override
    public boolean touchUp(int x, int y, int pointer, int button) {


        if (runner.isDodging()) {
            runner.stopDodge();
        }

        return super.touchDown(x, y, pointer, button);
    }

    private boolean rightSideTouched(float x, float y) {
        return screenRightSide.contains(x, y);
    }

    private boolean leftSideTouched(float x, float y) {
        return screenLeftSide.contains(x, y);
    }

    /**
     * Helper function to get the actual coordinates in my world
     * @param x
     * @param y
     */
    private void translateScreenToWorldCoordinates(int x, int y) {
        getCamera().unproject(touchPoint.set(x, y, 0));
    }

    @Override
    public void beginContact(Contact contact) {

        Body a = contact.getFixtureA().getBody();
        Body b = contact.getFixtureB().getBody();

        if ((bodyIsRunner(a) && bodyIsGround(b)) ||
                (bodyIsGround(a) && bodyIsRunner(b))) {
            runner.landed();
        }

    }

    @Override
    public void endContact(Contact contact) {

    }

    @Override
    public void preSolve(Contact contact, Manifold oldManifold) {

    }

    @Override
    public void postSolve(Contact contact, ContactImpulse impulse) {

    }

}