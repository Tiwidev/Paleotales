package com.gametomax.paleotale.enums;

public enum UserDataType {

    GROUND,
    RUNNER

}